/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      width: {
        'w16%':'16%',
        'w200':'268px',
        'w420':'420px',
        'w400':'400px',
        'w60%':'60%',
        'w500':'500px',
        'w418':'418px',
        'w220':'220px',
        'w500':'500px',
        'w383':'382px',
        'wcalc':'calc(100% - 268px)'
      },
      height: {
        'h1px':'1px',
        '100h':'100vh',
        'h275px':'275px',
        'h262':'262px',
        'h300':'310px'
      },
      fontWeight: {
        'font900':'900'
      },
      colors: {
        'darkyellow':'#fbd00e',
        'bgwhitesmoke':'whitesmoke',
      },
      borderRadius: {
        'rounded18':'18px'
      },
      fontFamily: {
        'nunito':'Nunito',
        'railway':'Raleway, sans-serif'
      },
      margin:{
        'm10':'10px',
        'm4':'4px'
      },
      fontSize: {
        'font22':'22px',
        'font10':'10px'
      },
      boxShadow: {

      },
      gap: {
        'gap46':'46px',
        'gap35':'35px'
      },
      letterSpacing: {
        'space1':'1px'
      },
      backgroundColor: {
        'bgyellow': '#fbd00e'
      }
    },
  },
  plugins: [],
}
