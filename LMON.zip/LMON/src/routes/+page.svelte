<script>
    import "../app.css";
  </script>

<div class="w-full h-100h flex bg-bgwhitesmoke">
   <div class="bg-darkyellow max-h-screen w-w200 content-center">        
       <aside class="container px-6" aria-label="Sidebar">
           <div class="overflow-y-auto py-4 px-8 rounded flex flex-col h-100h justify-between">
            <div>
               <ul class="space-y-2 pt-11">
                  <img class="mb-6" src="/logo.png" alt="" width="140px" height="140px">
                  <div class="my-7 mx-0 bg-black h-h1px w-36">

                  </div>
                 <li class="pt-6">
                    <a href="#" class="flex items-center p-2 text-base font-normal rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M575.8 255.5c0 18-15 32.1-32 32.1h-32l.7 160.2c.2 35.5-28.5 64.3-64 64.3H128.1c-35.3 0-64-28.7-64-64V287.6H32c-18 0-32-14-32-32.1c0-9 3-17 10-24L266.4 8c7-7 15-8 22-8s15 2 21 7L416 100.7V64c0-17.7 14.3-32 32-32h32c17.7 0 32 14.3 32 32V185l52.8 46.4c8 7 12 15 11 24zM248 192c-13.3 0-24 10.7-24 24v80c0 13.3 10.7 24 24 24h80c13.3 0 24-10.7 24-24V216c0-13.3-10.7-24-24-24H248z"/></svg>
                       <span class="ml-3 text-sm	">Home</span>
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M0 96C0 43 43 0 96 0H384h32c17.7 0 32 14.3 32 32V352c0 17.7-14.3 32-32 32v64c17.7 0 32 14.3 32 32s-14.3 32-32 32H384 96c-53 0-96-43-96-96V96zM64 416c0 17.7 14.3 32 32 32H352V384H96c-17.7 0-32 14.3-32 32zM247.4 283.8c-3.7 3.7-6.2 4.2-7.4 4.2s-3.7-.5-7.4-4.2c-3.8-3.7-8-10-11.8-18.9c-6.2-14.5-10.8-34.3-12.2-56.9h63c-1.5 22.6-6 42.4-12.2 56.9c-3.8 8.9-8 15.2-11.8 18.9zm42.7-9.9c7.3-18.3 12-41.1 13.4-65.9h31.1c-4.7 27.9-21.4 51.7-44.5 65.9zm0-163.8c23.2 14.2 39.9 38 44.5 65.9H303.5c-1.4-24.7-6.1-47.5-13.4-65.9zM368 192c0-70.7-57.3-128-128-128s-128 57.3-128 128s57.3 128 128 128s128-57.3 128-128zM145.3 208h31.1c1.4 24.7 6.1 47.5 13.4 65.9c-23.2-14.2-39.9-38-44.5-65.9zm31.1-32H145.3c4.7-27.9 21.4-51.7 44.5-65.9c-7.3 18.3-12 41.1-13.4 65.9zm56.1-75.8c3.7-3.7 6.2-4.2 7.4-4.2s3.7 .5 7.4 4.2c3.8 3.7 8 10 11.8 18.9c6.2 14.5 10.8 34.3 12.2 56.9h-63c1.5-22.6 6-42.4 12.2-56.9c3.8-8.9 8-15.2 11.8-18.9z"/></svg>
                       <span class="ml-3 text-sm">Bookings</span>                      
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M352 256c0 22.2-1.2 43.6-3.3 64H163.3c-2.2-20.4-3.3-41.8-3.3-64s1.2-43.6 3.3-64H348.7c2.2 20.4 3.3 41.8 3.3 64zm28.8-64H503.9c5.3 20.5 8.1 41.9 8.1 64s-2.8 43.5-8.1 64H380.8c2.1-20.6 3.2-42 3.2-64s-1.1-43.4-3.2-64zm112.6-32H376.7c-10-63.9-29.8-117.4-55.3-151.6c78.3 20.7 142 77.5 171.9 151.6zm-149.1 0H167.7c6.1-36.4 15.5-68.6 27-94.7c10.5-23.6 22.2-40.7 33.5-51.5C239.4 3.2 248.7 0 256 0s16.6 3.2 27.8 13.8c11.3 10.8 23 27.9 33.5 51.5c11.6 26 21 58.2 27 94.7zm-209 0H18.6C48.6 85.9 112.2 29.1 190.6 8.4C165.1 42.6 145.3 96.1 135.3 160zM8.1 192H131.2c-2.1 20.6-3.2 42-3.2 64s1.1 43.4 3.2 64H8.1C2.8 299.5 0 278.1 0 256s2.8-43.5 8.1-64zM194.7 446.6c-11.6-26-20.9-58.2-27-94.6H344.3c-6.1 36.4-15.5 68.6-27 94.6c-10.5 23.6-22.2 40.7-33.5 51.5C272.6 508.8 263.3 512 256 512s-16.6-3.2-27.8-13.8c-11.3-10.8-23-27.9-33.5-51.5zM135.3 352c10 63.9 29.8 117.4 55.3 151.6C112.2 482.9 48.6 426.1 18.6 352H135.3zm358.1 0c-30 74.1-93.6 130.9-171.9 151.6c25.5-34.2 45.2-87.7 55.3-151.6H493.4z"/></svg>
                       <span class="ml-3 text-sm">Tours</span>
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M135.2 117.4L109.1 192H402.9l-26.1-74.6C372.3 104.6 360.2 96 346.6 96H165.4c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32H346.6c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2V400v48c0 17.7-14.3 32-32 32H448c-17.7 0-32-14.3-32-32V400H96v48c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32V400 256c0-26.7 16.4-49.6 39.6-59.2zM128 288c0-17.7-14.3-32-32-32s-32 14.3-32 32s14.3 32 32 32s32-14.3 32-32zm288 32c17.7 0 32-14.3 32-32s-14.3-32-32-32s-32 14.3-32 32s14.3 32 32 32z"/></svg>
                       <span class="ml-3 text-sm">Car Rentals</span>
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M144 208C126.3 208 112 222.2 112 239.1C112 257.7 126.3 272 144 272s31.1-14.25 31.1-32S161.8 208 144 208zM256 207.1c-17.75 0-31.1 14.25-31.1 32s14.25 31.1 31.1 31.1s31.1-14.25 31.1-31.1S273.8 207.1 256 207.1zM368 208c-17.75 0-31.1 14.25-31.1 32s14.25 32 31.1 32c17.75 0 31.99-14.25 31.99-32C400 222.2 385.8 208 368 208zM256 31.1c-141.4 0-255.1 93.12-255.1 208c0 47.62 19.91 91.25 52.91 126.3c-14.87 39.5-45.87 72.88-46.37 73.25c-6.624 7-8.373 17.25-4.624 26C5.818 474.2 14.38 480 24 480c61.49 0 109.1-25.75 139.1-46.25c28.87 9 60.16 14.25 92.9 14.25c141.4 0 255.1-93.13 255.1-207.1S397.4 31.1 256 31.1zM256 400c-26.75 0-53.12-4.125-78.36-12.12l-22.75-7.125L135.4 394.5c-14.25 10.12-33.87 21.38-57.49 29c7.374-12.12 14.37-25.75 19.87-40.25l10.62-28l-20.62-21.87C69.81 314.1 48.06 282.2 48.06 240c0-88.25 93.24-160 207.1-160s207.1 71.75 207.1 160S370.8 400 256 400z"/></svg>
                       <span class="ml-3 text-sm">Administration</span>
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zm90.7 96.7c9.7-2.6 19.9 2.3 23.7 11.6l20 48c3.4 8.2 1 17.6-5.8 23.2L168 231.7c16.6 35.2 45.1 63.7 80.3 80.3l20.2-24.7c5.6-6.8 15-9.2 23.2-5.8l48 20c9.3 3.9 14.2 14 11.6 23.7l-12 44C336.9 378 329 384 320 384C196.3 384 96 283.7 96 160c0-9 6-16.9 14.7-19.3l44-12z"/></svg>
                       <span class="ml-3 text-sm">Support</span>
                    </a>
                 </li>
                 <li>
                    <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                       <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M448 96V224H288V96H448zm0 192V416H288V288H448zM224 224H64V96H224V224zM64 288H224V416H64V288zM64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64z"/></svg>
                       <span class="ml-3 text-sm">Settings</span>
                    </a>
                 </li>
              </ul>
            </div>
            <div>
               <ul>
                  <li>
                     <a href="#" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg text-black hover:bg-white dark:hover:bg-white">
                        <svg class="w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M534.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L434.7 224 224 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l210.7 0-73.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l128-128zM192 96c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0c-53 0-96 43-96 96l0 256c0 53 43 96 96 96l64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l64 0z"/></svg>
                        <span class="ml-3 text-sm">Logout</span>
                     </a>
                  </li>
               </ul>
            </div>
           </div>
       </aside>
   </div>
   <div class="w-wcalc p-5 max-h-screen justify-around">
      <div class="flex justify-around w-full mt-4">
         <div>
            <h1 class="text-3xl font-semibold">Hello, Elba Hotel!</h1>
            <p class="sub-head">Welcome back & let's grow.</p>
         </div> 
         <div class="search flex h-14 w-2/4 items-center rounded-3xl">
            <svg class="w-5 m-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352c79.5 0 144-64.5 144-144s-64.5-144-144-144S64 128.5 64 208s64.5 144 144 144z"/></svg>
            <input
              type="search"
              class="
                form-control
                block
                w-full
                px-3
                py-1.5
                text-base
                font-normal
                text-gray-700
                bg-transparent bg-clip-padding
                rounded
                transition
                ease-in-out
                m-0
                focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none
              "
              id="exampleSearch2"
              placeholder="New Year Trek Adventure"
            />
         </div>
         <div class="flex gap-2.5">
            <div class="bell w-11 h-11 rounded-3xl br1">
               <svg class="w-5 mt-2 ml-3 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M224 0c-17.7 0-32 14.3-32 32V51.2C119 66 64 130.6 64 208v18.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S19.4 416 32 416H416c12.6 0 24-7.4 29.2-18.9s3.1-25-5.3-34.4l-7.4-8.3C401.3 319.2 384 273.9 384 226.8V208c0-77.4-55-142-128-156.8V32c0-17.7-14.3-32-32-32zm45.3 493.3c12-12 18.7-28.3 18.7-45.3H224 160c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"/></svg>
            </div>
            <div class=" w-11 h-11 rounded-3xl br1 bg-darkyellow">
               <svg class="w-5 mt-3 ml-3 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
            </div>
         </div>
      </div>
      <div class="w-full mt-5 flex">
         <div class="">
            <div class="flex m-3">
               <h1 class="heading-1 text-font22 font-bold ">Most Popular</h1>
               <h1 class="ml-auto text-xl">See All</h1>
            </div>
            <div class="sub-container bg-white w-full h-h275px rounded-3xl">
               <div class="flex justify-center">
                  <div class="m-2">
                     <img src="/Screenshot 2023-01-01 at 9.14.27 PM.png" alt="" width="300px" height="272px">
                  </div>
                  <div class="w-w420 h-h262 m-m10">
                     <div class="flex">
                        <h2 class="text-xl font-semibold">
                           VUELTA A MALLORCA <br>
                           EN HELICÓPTERO
                        </h2>
                        <div class="flex ml-auto gap-7 items-center">
                           <svg class="w-9 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"/></svg>
                           <span class="text-xl">
                              4.9
                           </span>
                        </div>
                     </div>
                     <div class="flex my-3">
                        <svg class="w-9 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 256c-35.3 0-64-28.7-64-64s28.7-64 64-64s64 28.7 64 64s-28.7 64-64 64z"/></svg>
                        <h1 class="text-base">Mallorca</h1>
                     </div>
                     <div class="text-sm text-gray-400 my-3">
                        Descubre Mallorca con este nuevo tour
                        desde dentro de nuestros helicópteros. Te
                        enseñaremos la isla desde otro punto de
                        vista y viviras una aventura inolvidable.
                        Nuestra aventura empieza en el...
                     </div>
                     <div class="flex my-3 justify-evenly">
                        <button class="flex w-64 justify-center items-center h-11 rounded-xl text-white bg-red-500">
                           <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                           99.9
                        </button>
                        <div class=" w-11 h-11 rounded-3xl br1 bg-darkyellow">
                           <svg class="w-5 mt-3 ml-3 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="w-w500 mt-9">
            <div class="sub-container-2 bg-white w-w418 h-h275px m-5 rounded-rounded18 ">
               <div class="flex p-4 items-center">
                  <div>ACITIVITY</div>
                  <div class="flex ml-auto gap-4">
                     <svg class="w-3 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M41.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 256 278.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                     <span class="mt-m4">
                        Jan 2023
                     </span>
                     <svg class="w-3 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M342.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                  </div>
               </div>
               <div class="flex gap-gap35 text-gray-400 text-xs justify-center my-4">
                  <p>SUN</p>
                  <p>MON</p>
                  <p>TUE</p>
                  <p>WED</p>
                  <p>THU</p>
                  <p>FRI</p>
                  <p>SAT</p>
               </div>
               <div class="flex text-xs justify-around my-4">
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">01</p>
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">02</p>
                  <p>03</p>
                  <p>04</p>
                  <p>05</p>
                  <p>06</p>
                  <p>07</p>
               </div>
               <div class="flex text-xs justify-around my-4">
                  <p>08</p>
                  <p>09</p>
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">10</p>
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">11</p>
                  <p>12</p>
                  <p>13</p>
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">14</p>
               </div>
               <div class="flex justify-around text-xs my-4">
                  <p>15</p>
                  <p>16</p>
                  <p>17</p>
                  <p>18</p>
                  <p>19</p>
                  <p>20</p>
                  <p>21</p>
               </div>
               <div class="flex justify-around text-xs my-4">
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">22</p>
                  <p class="bg-yellow-400 rounded-xl text-center h-4 w-4">23</p>
                  <p>24</p>
                  <p>25</p>
                  <p>26</p>
                  <p>27</p>
                  <p class="bg-yellow-400 rounded-xl text-center h-4 w-4">28</p>
               </div>
               <div class="flex text-xs justify-around my-4">
                  <p>29</p>
                  <p class="bg-green-400 rounded-xl text-center h-4 w-4">30</p>
                  <p>31</p>
                  <p>01</p>
                  <p>02</p>
                  <p>03</p>
                  <p>04</p>
               </div>
            </div>
         </div>

      </div>
      <div class="w-full mt-7 flex">
         <div class="flex gap-2.5">
            <div class="sub-container-3 bg-white w-w220 h-h300 rounded-xl">
               <img class="py-2 px-2" src="/pic1.png" alt="" width="220px" height="150px">
               <div class="flex py-0 px-2">
                  <h2 class="text-sm font-bold">
                     Palma - Private <br>
                     Guided Tour
                  </h2>
                  <div class="flex ml-auto gap-3">
                     <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"/></svg>
                     <span class="text-xs">
                        4.9
                     </span>
                  </div>
               </div>
               <div class="flex py-1 px-2 items-center">
                  <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 256c-35.3 0-64-28.7-64-64s28.7-64 64-64s64 28.7 64 64s-28.7 64-64 64z"/></svg>
                  <h1 class="text-xs">Palma</h1>
               </div>
               <div class="text-font10 py-1 px-2 text-gray-400">
                  Classical façades, medieval
                  alleys, secret corners of past...
               </div>
               <div class="flex px-2">
                  <button class="w-40 h-8 justify-center items-center rounded-xl text-white bg-red-500 flex">
                     <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                     250.00
                  </button>
                  <div class=" w-8 h-8 ml-1 rounded-3xl br1 bg-darkyellow">
                     <svg class="w-4 mt-2 ml-2 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
                  </div>
               </div>
            </div>
            <div class="sub-container-3 bg-white w-w220 h-h300 rounded-xl">
               <img class="py-1 px-2" src="/pic2.png" alt="" width="220px" height="150px">
               <div class="flex py-0 px-2">
                  <h2 class="text-sm font-bold">
                     Ibiza - Boat Only<br>
                     (Ferry Ticket)
                  </h2>
                  <div class="flex ml-auto gap-3">
                     <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"/></svg>
                     <span class="text-xs">
                        4.9
                     </span>
                  </div>
               </div>
               <div class="flex py-1 px-2 items-center">
                  <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 256c-35.3 0-64-28.7-64-64s28.7-64 64-64s64 28.7 64 64s-28.7 64-64 64z"/></svg>
                  <h1 class="text-xs">Ibiza</h1>
               </div>
               <div class="text-font10 py-1 px-2 text-gray-400">
                  Enjoy a day in Ibiza at your own
                  pace! Declared a World...
               </div>
               <div class="flex px-2">
                  <button class="w-40 h-8 justify-center items-center rounded-xl text-white bg-red-500 flex">
                     <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                     75.00
                  </button>
                  <div class=" w-8 h-8 ml-1 rounded-3xl br1 bg-darkyellow">
                     <svg class="w-4 mt-2 ml-2 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
                  </div>
               </div>
            </div>
            <div class="sub-container-3 bg-white w-w220 h-h300 rounded-xl">
               <img class="py-1 px-2" src="/pic3.png" alt="" width="220px" height="150px">
               <div class="flex py-0 px-2">
                  <h2 class="text-sm font-bold">
                     Cova de Colom <br>
                     Sea Caves
                  </h2>
                  <div class="flex ml-auto gap-3">
                     <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"/></svg>
                     <span class="text-xs">
                        4.9
                     </span>
                  </div>
               </div>
               <div class="flex py-1 px-2 items-center">
                  <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 256c-35.3 0-64-28.7-64-64s28.7-64 64-64s64 28.7 64 64s-28.7 64-64 64z"/></svg>
                  <h1 class="text-xs">Mallorca</h1>
               </div>
               <div class="text-font10 py-1 px-2 text-gray-400">
                  Classical façades, medieval
                  alleys, secret corners of past...
               </div>
               <div class="flex px-2">
                  <button class="w-40 h-8 justify-center items-center rounded-xl text-white bg-red-500 flex">
                     <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                     65.00
                  </button>
                  <div class=" w-8 h-8 ml-1 rounded-3xl br1 bg-darkyellow">
                     <svg class="w-4 mt-2 ml-2 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
                  </div>
               </div>
            </div>
         </div>
         <div class="gap-4 w-w500 mt-0">
            <div class=" ml-4">
               <h1 class="text-xl font-bold tracking-space1" style="font-family: 'IBM Plex Sans', sans-serif;">
                  Bookings
               </h1>
            </div>
            <div class="card my-4 mx-4 bg-white flex w-w383 h-14 items-center justify-around rounded-xl">
               <h1 class="text-2xl">Total Revenue</h1>
               <div class="flex gap-4">
                  <svg class="w-4 mt-1 ml-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                  <p class="text-3xl text-green-500">9700.00</p>
               </div>
            </div>
            <div class="card my-4 mx-4 bg-white flex w-w383 h-14 items-center justify-around rounded-xl">
               <h1 class="text-2xl">This Month</h1>
               <div class="flex gap-4">
                  <svg class="w-4 mt-1 ml-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                  <p class="text-3xl text-orange-400">590.00</p>
               </div>
            </div>
            <div class="card my-4 mx-4 bg-white flex w-w383 h-14 items-center justify-around rounded-xl">
               <h1 class="text-2xl">Total Bookings</h1>
               <div class="flex gap-4">
                  <svg class="w-4 mt-1 ml-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M0 64C0 46.3 14.3 32 32 32H96h16H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H231.8c9.6 14.4 16.7 30.6 20.7 48H288c17.7 0 32 14.3 32 32s-14.3 32-32 32H252.4c-13.2 58.3-61.9 103.2-122.2 110.9L274.6 422c14.4 10.3 17.7 30.3 7.4 44.6s-30.3 17.7-44.6 7.4L13.4 314C2.1 306-2.7 291.5 1.5 278.2S18.1 256 32 256h80c32.8 0 61-19.7 73.3-48H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H185.3C173 115.7 144.8 96 112 96H96 32C14.3 96 0 81.7 0 64z"/></svg>
                  <p class="text-3xl text-green-500">107</p>
               </div>
            </div>
            <div class="card my-4 mx-4 bg-black flex w-w383 h-14 items-center justify-around rounded-xl">
               <h1 class="text-2xl text-white">See all</h1>
            </div>
         </div>
         <!-- <div class=" w-6 h-6 rounded-3xl br1 bg-darkyellow">
            <svg class="w-4 mt-2 ml-1 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M447.1 0h-384c-35.25 0-64 28.75-64 63.1v287.1c0 35.25 28.75 63.1 64 63.1h96v83.98c0 9.836 11.02 15.55 19.12 9.7l124.9-93.68h144c35.25 0 64-28.75 64-63.1V63.1C511.1 28.75 483.2 0 447.1 0zM464 352c0 8.75-7.25 16-16 16h-160l-80 60v-60H64c-8.75 0-16-7.25-16-16V64c0-8.75 7.25-16 16-16h384c8.75 0 16 7.25 16 16V352z"/></svg>
         </div> -->
         <div class="w-11 h-9 rounded-3xl bg-darkyellow mt-52" style="box-shadow: rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px;">
            <svg class="w-4 mt-3 ml-3 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M447.1 0h-384c-35.25 0-64 28.75-64 63.1v287.1c0 35.25 28.75 63.1 64 63.1h96v83.98c0 9.836 11.02 15.55 19.12 9.7l124.9-93.68h144c35.25 0 64-28.75 64-63.1V63.1C511.1 28.75 483.2 0 447.1 0zM464 352c0 8.75-7.25 16-16 16h-160l-80 60v-60H64c-8.75 0-16-7.25-16-16V64c0-8.75 7.25-16 16-16h384c8.75 0 16 7.25 16 16V352z"/></svg>
         </div>
      </div>
   </div>
</div>